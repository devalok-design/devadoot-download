# Devalok Hiring Guide

> **आत्मतः शिल्पं कृत्वा** — "From the soul, we craft."

This file covers hiring philosophy, recruitment process, and onboarding at Devalok.

---

## Hiring Philosophy

### What We Look For

Devalok seeks individuals who embody:

| Quality | Description |
|---------|-------------|
| **Craft & Care** | Attention to detail is non-negotiable |
| **Meaning-first Mindset** | Always ask "why" before "how" |
| **Collaboration Spirit** | Design grows stronger through multiple perspectives |
| **Curiosity** | Willing to ask clarifying questions and explore |
| **Cultural Alignment** | Respect for Indian heritage and aesthetic sensibilities |
| **Growth Orientation** | Open to learning, feedback, and development |

### The Devalok Way

> "We believe we are mediums of expression for the universe to bring its best ideas to life. This philosophy ensures we never carry the ego of 'I created this' but rather stay forever humble."

**Candidates should resonate with:**
- **Story-driven** approach — Lead with meaning and narrative
- **Values-forward** mindset — Purpose before process
- **Collaborative nature** — Working together without silos
- **Warmth** — Speaking to people, not at them

---

## Roles at Devalok

### Role Definitions

Roles are responsibilities, not ranks. Leadership is rotational.

| Role | Description | Key Responsibilities |
|------|-------------|---------------------|
| **Apprentice** | In training | Learns by doing. Skill-building and exposure. |
| **ADA (Assistant Design Associate)** | Works independently | Understands process. Contributes to projects autonomously. |
| **DA (Design Associate)** | Expert in one area | Mentors ADAs. Leads aspects of projects. |
| **DD (Design Director)** | Creative direction | Supports multiple teams. Provides creative direction. |
| **Founder** | Sets direction | Steps in when needed. Supports overall project health. |

### Specialized Roles

| Role | Focus Area |
|------|------------|
| **Content Associate** | Copywriting, content strategy, brand voice |
| **Operations Associate/Apprentice** | Operations, administration, coordination |
| **US Representative** | US client relations and operations |
| **Director of Stewardship** | People and culture, team operations |

---

## Recruitment Process

### Stage 1: Application

**Requirements:**
- Portfolio (mandatory)
- Resume/CV
- Relevant work samples

**Channels:**
- Email: pac@devalok.in
- Google Forms (role-specific)
- LinkedIn applications

### Stage 2: Review & Screening

- Educational qualifications review
- Portfolio evaluation
- Background check

### Stage 3: Interviews

**Conducted by:** Founder and/or relevant team leads

**Focus Areas:**
- Skills assessment
- Cultural fit
- Design thinking and process
- Communication abilities

### Stage 4: Offer & Documentation

- Offer letter issued
- Employment/Apprenticeship agreement signed
- Onboarding packet shared

---

## Employment Types

### Full-Time Associates

- Design Associates (DA)
- Assistant Design Associates (ADA)
- Content Associates
- Operations Associates

### Apprenticeship Program

| Aspect | Details |
|--------|---------|
| **Duration** | Typically 3-6 months |
| **Compensation** | Monthly stipend provided |
| **Focus** | Learning and skill development |
| **Path** | Full-time employment upon successful completion |

### Apprentice Responsibilities

1. **Design Assistance** — Participate in creation and refinement of design elements
2. **Creative Research** — Explore design trends, gather insights
3. **Team Collaboration** — Engage in discussions, provide input, receive feedback
4. **Project Support** — Assist in managing timelines, ensure efficiency
5. **Professional Development** — Participate in learning activities

---

## Compensation & Benefits

### Salary Structure

| Aspect | Details |
|--------|---------|
| **Payment Schedule** | Bi-weekly (not monthly) |
| **Market Position** | Above market standards |
| **Deductions** | Applicable statutory deductions (TDS, etc.) |

### Leave Policy

- **122 break days per year** with complete flexibility
- No predefined weekends
- Up to 21 days carry forward
- Unused days can convert to compensation

### Additional Benefits

- Remote work flexibility
- Team trips and gatherings
- Learning and development opportunities
- Equal opportunity employment
- Clean, safe, healthy work environment

---

## Onboarding Process

### Pre-Joining

1. Offer letter issued and signed
2. Employment/Apprenticeship agreement executed
3. Background verification completed
4. Original certificates reviewed

### Day 1 Essentials

- Welcome to the team
- Introduction to Lokwasis
- Access to systems:
  - Karm (attendance/payroll)
  - Karyakram (project recordkeeping)
  - Lokgranth (internal handbook)
  - Portal (task management)

### First Week

- Team introductions
- Process orientation
- Tool and system setup
- Assignment to initial project

### Ongoing

- Regular check-ins with supervisor
- Learning and development activities
- Feedback sessions
- Integration into team culture

---

## Writing Job Posts

### Tone

- Warm, inviting, clear
- Reflects Devalok's voice
- Avoids corporate jargon
- Emphasizes culture and values

### Structure

1. **Opening** — What makes Devalok different
2. **The Role** — What they'll do, not just requirements
3. **Who You Are** — Qualities we're looking for
4. **What We Offer** — Benefits and culture
5. **How to Apply** — Clear instructions

### Example Opening

> "We're not looking for someone who just checks boxes. We're looking for someone who cares deeply about craft, thinks in systems, and believes that design should hold meaning."

### ❌ Avoid

- Generic job description language
- Long requirement lists
- "Rockstar" or "ninja" terminology
- Salary ranges (discuss in interview)

---

## Interview Guidelines

### For Interviewers

1. **Be warm and welcoming** — This is their first real experience of Devalok
2. **Ask about process** — How they think, not just what they've done
3. **Look for curiosity** — Do they ask questions?
4. **Assess collaboration** — How do they talk about working with others?
5. **Check cultural fit** — Do they resonate with our philosophy?

### Good Interview Questions

- "Walk me through your favorite project. What made it meaningful to you?"
- "Tell me about a time you disagreed with feedback. How did you handle it?"
- "What does 'craft' mean to you?"
- "How do you approach a project when the brief is unclear?"
- "What kind of work environment helps you do your best work?"

### Red Flags

- Takes sole credit for team work
- Dismissive of feedback
- Focused only on tools, not thinking
- No questions about Devalok
- Doesn't align with collaborative values

---

## Document Templates

### Available Templates

| Template | Location |
|----------|----------|
| Employment Offer Letter | [Google Doc](https://docs.google.com/document/d/1OhpoJOYyAITtH-XTrfFkZwSizx6eeFBKYoo48wckZ4w/edit) |
| Apprenticeship Agreement | [Google Doc](https://docs.google.com/document/d/1-w0FTV9LI0uSKw1E_eKP44VaGxe2NhEEULasWDGJzzM/edit) |
| Onboarding Packet | [Google Doc](https://docs.google.com/document/d/18dZsgyk7W7mdXjXMB5QD7e6fOE7ZpaXb_RO8qKOYYk0/edit) |
| Break Framework | [Google Doc](https://docs.google.com/document/d/1qLCBobNS5B1211aO0gsHAdwKTPw6DmU901E0k8-tPBI/edit) |
| Lokgranth (Handbook) | [Google Doc](https://docs.google.com/document/d/133Oloz30-g1r6B2rpchEjGyMZwm2-Ma0Vh3HTKBODn4/edit) |

---

## Hiring Checklist

### For Each Candidate

- [ ] Application received with portfolio
- [ ] Educational/qualification certificates reviewed
- [ ] Background check completed
- [ ] Interview conducted
- [ ] Offer letter issued
- [ ] Agreement signed
- [ ] Systems access provided (Karm, Karyakram, etc.)
- [ ] Onboarding completed

### Key Principles

1. **Portfolio is mandatory** — Always require work samples
2. **Cultural fit matters** — Alignment with Devalok values
3. **Assess collaboration** — Team dynamics are essential
4. **Communication skills** — Clear, warm, professional
5. **Growth mindset** — Willingness to learn and develop

---

## Contact for Hiring

| Purpose | Contact |
|---------|---------|
| **People & Culture** | pac@devalok.in |
| **General Inquiries** | hello@devalok.in |

---

*Reference: hiring.md | Version 2.0.0*
