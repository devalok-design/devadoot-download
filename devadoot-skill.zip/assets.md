# Devalok Brand Assets

> Use these URLs in HTML emails, web outputs, and documents.

All URLs are pre-encoded and ready to use. Assets hosted on jsDelivr CDN.

---

## Quick Selection Guide

| Use Case | Recommended Asset | Format |
|----------|-------------------|--------|
| **Email Header** | COLOR Monogram + Wordmark | PNG |
| **Email Footer** | COLOR Monogram | PNG |
| **Dark Background** | WHITE variants | PNG |
| **Light Background** | BLACK or COLOR variants | PNG |
| **Web Favicon** | COLOR 32pt | PNG |
| **Apple Touch Icon** | COLOR 180pt | PNG |
| **PWA Icon** | COLOR 512pt | PNG |
| **Web Logo (scalable)** | SVG variants | SVG |

---

## Logos — PNG (Recommended for Emails)

### COLOR Variants

#### Monogram (Icon Only)
```
https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/PNG/COLOR/COLOR%20-%20Monogram.png
```

#### Monogram + Wordmark (Logo with Text) ⭐ Most Common
```
https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/PNG/COLOR/COLOR%20-%20Monogram%20%2B%20Wordmark-01-01.png
```

#### Monogram + Shell
```
https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/PNG/COLOR/COLOR%20-%20Monogram%20%2B%20Shell-01.png
```

#### Monogram + Shell + Wordmark
```
https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/PNG/COLOR/COLOR%20-%20Monogram%20%2B%20Shell%20%2B%20Wordmark-01.png
```

#### Monogram + Coin + Wordmark
```
https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/PNG/COLOR/COLOR%20-%20Monogram%20%2B%20Coin%20%2B%20Wordmark-01.png
```

#### Wordmark Only
```
https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/PNG/COLOR/COLOR%20-%20Wordmark-01.png
```

#### Wordmark DASS
```
https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/PNG/COLOR/COLOR%20-%20Wordmark%20DASS-01.png
```

#### Wordmark SHLOKA
```
https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/PNG/COLOR/COLOR%20-%20Wordmark%20SHLOKA-01.png
```

---

### BLACK Variants (For Light Backgrounds)

#### Monogram
```
https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/PNG/BLACK/BLACK%20-%20Monogram.png
```

#### Monogram + Wordmark
```
https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/PNG/BLACK/BLACK%20-%20Monogram%20%2B%20Wordmark-01.png
```

#### Monogram + Shell
```
https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/PNG/BLACK/BLACK%20-%20Monogram%20%2B%20Shell-01.png
```

#### Monogram + Shell + Wordmark
```
https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/PNG/BLACK/BLACK%20-%20Monogram%20%2B%20Shell%20%2B%20Wordmark-01.png
```

#### Monogram + Coin + Wordmark
```
https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/PNG/BLACK/BLACK%20-%20Monogram%20%2B%20Coin%20%2B%20Wordmark-01.png
```

#### Wordmark Only
```
https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/PNG/BLACK/BLACK%20-%20Wordmark-01.png
```

#### Wordmark DASS
```
https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/PNG/BLACK/BLACK%20-%20Wordmark%20DASS-01.png
```

#### Wordmark SHLOKA
```
https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/PNG/BLACK/BLACK%20-%20Wordmark%20SHLOKA-01.png
```

---

### WHITE Variants (For Dark Backgrounds)

#### Monogram
```
https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/PNG/WHITE/WHITE%20-%20Monogram.png
```

#### Monogram + Wordmark
```
https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/PNG/WHITE/WHITE%20-%20Monogram%20%2B%20Wordmark-01.png
```

#### Monogram + Shell
```
https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/PNG/WHITE/WHITE%20-%20Monogram%20%2B%20Shell-01.png
```

#### Monogram + Shell + Wordmark
```
https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/PNG/WHITE/WHITE%20-%20Monogram%20%2B%20Shell%20%2B%20Wordmark-01.png
```

#### Monogram + Coin + Wordmark
```
https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/PNG/WHITE/WHITE%20-%20Monogram%20%2B%20Coin%20%2B%20Wordmark-01.png
```

#### Wordmark Only
```
https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/PNG/WHITE/WHITE%20-%20Wordmark-01.png
```

#### Wordmark DASS
```
https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/PNG/WHITE/WHITE%20-%20Wordmark%20DASS-01.png
```

#### Wordmark SHLOKA
```
https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/PNG/WHITE/WHITE%20-%20Wordmark%20SHLOKA-01.png
```

---

## Logos — SVG (For Web — Not Emails)

### COLOR SVG

#### Monogram
```
https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/SVG/COLOR/COLOR%20-%20Monogram-01.svg
```

#### Monogram + Wordmark
```
https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/SVG/COLOR/COLOR%20-%20Monogram%20%2B%20Wordmark-01-01.svg
```

#### Monogram + Shell
```
https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/SVG/COLOR/COLOR%20-%20Monogram%20%2B%20Shell-01.svg
```

#### Monogram + Shell + Wordmark
```
https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/SVG/COLOR/COLOR%20-%20Monogram%20%2B%20Shell%20%2B%20Wordmark-01.svg
```

#### Wordmark
```
https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/SVG/COLOR/COLOR%20-%20Wordmark-01.svg
```

---

## Favicons

### COLOR Favicons

| Size | Usage | URL |
|------|-------|-----|
| **16pt** | Browser Tab | `https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Favicon/COLOR/PNG/Favicon_COLOR%20%2816%20pt%29.png` |
| **32pt** | Browser Tab (Retina) | `https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Favicon/COLOR/PNG/Favicon_COLOR%20%2832%20pt%29.png` |
| **96pt** | Desktop Shortcut | `https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Favicon/COLOR/PNG/Favicon_COLOR%20%2896%20pt%29.png` |
| **180pt** | Apple Touch Icon | `https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Favicon/COLOR/PNG/Favicon_COLOR%20%28180%20pt%29.png` |
| **512pt** | PWA / Manifest | `https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Favicon/COLOR/PNG/Favicon_COLOR%20%28512%20pt%29.png` |
| **1000pt** | High Resolution | `https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Favicon/COLOR/PNG/Favicon_COLOR%20%281000%20pt%29.png` |

### COLOR INVERSE Favicons

| Size | URL |
|------|-----|
| **16pt** | `https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Favicon/COLOR%20INVERSE/PNG/Favicon_COLOR%20INVERSE%20%2816%20pt%29.png` |
| **32pt** | `https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Favicon/COLOR%20INVERSE/PNG/Favicon_COLOR%20INVERSE%20%2832%20pt%29.png` |
| **96pt** | `https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Favicon/COLOR%20INVERSE/PNG/Favicon_COLOR%20INVERSE%20%2896%20pt%29.png` |
| **180pt** | `https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Favicon/COLOR%20INVERSE/PNG/Favicon_COLOR%20INVERSE%20%28180%20pt%29.png` |
| **512pt** | `https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Favicon/COLOR%20INVERSE/PNG/Favicon_COLOR%20INVERSE%20%28512%20pt%29.png` |
| **1000pt** | `https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Favicon/COLOR%20INVERSE/PNG/Favicon_COLOR%20INVERSE%20%281000%20pt%29.png` |

### BLACK Favicons

| Size | URL |
|------|-----|
| **16pt** | `https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Favicon/BLACK/PNG/Favicon_BLACK%20%2816%20pt%29.png` |
| **32pt** | `https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Favicon/BLACK/PNG/Favicon_BLACK%20%2832%20pt%29.png` |
| **96pt** | `https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Favicon/BLACK/PNG/Favicon_BLACK%20%2896%20pt%29.png` |
| **180pt** | `https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Favicon/BLACK/PNG/Favicon_BLACK%20%28180%20pt%29.png` |
| **512pt** | `https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Favicon/BLACK/PNG/Favicon_BLACK%20%28512%20pt%29.png` |
| **1000pt** | `https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Favicon/BLACK/PNG/Favicon_BLACK%20%281000%20pt%29.png` |

### WHITE Favicons

| Size | URL |
|------|-----|
| **16pt** | `https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Favicon/WHITE/PNG/Favicon_WHITE%20Favicon%20%2816%20pt%29.png` |
| **32pt** | `https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Favicon/WHITE/PNG/Favicon_WHITE%20Favicon%20%2832%20pt%29.png` |
| **96pt** | `https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Favicon/WHITE/PNG/Favicon_WHITE%20Favicon%20%2896%20pt%29.png` |
| **180pt** | `https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Favicon/WHITE/PNG/Favicon_WHITE%20%28180%20pt%29.png` |
| **512pt** | `https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Favicon/WHITE/PNG/Favicon_WHITE%20%28512%20pt%29.png` |
| **1000pt** | `https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Favicon/WHITE/PNG/Favicon_WHITE%20%281000%20pt%29.png` |

---

## HTML Email Templates

> Sharp, editorial design with Playfair Display headlines and Inter body text.
> Deep pink footer (#712846) with white branding. Light pink (#FCF7F7) for highlights.

### Design Principles

- **Typography**: Playfair Display for headlines (editorial feel), Inter for body text (modern readability)
- **Colors**: Devalok Pink (#D33163) for primary accents, Light Pink (#FCF7F7) for backgrounds, Deep Pink (#712846) for footer
- **Layout**: Clean, sharp edges — no border-radius. Table-based for email compatibility.
- **Branding**: Monogram (flower) in header, white monogram on deep pink footer

### Font Import for Emails

Add this at the top of your HTML email `<head>`:

```html
<!--[if mso]>
<style type="text/css">
  body, table, td { font-family: Arial, sans-serif !important; }
</style>
<![endif]-->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Playfair+Display:ital,wght@0,400;0,500;0,600;1,400&display=swap" rel="stylesheet">
```

**Font Compatibility:**
- Inter & Playfair Display load in: Apple Mail, iOS Mail, Outlook for Mac, Samsung Mail, webmail clients
- Falls back to Georgia/Arial in: Outlook for Windows (uses MSO conditional)

---

### Email Header (Light Background)

```html
<div style="padding: 48px 48px 40px; text-align: center; background-color: #ffffff;">
  <img
    src="https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/PNG/COLOR/COLOR%20-%20Monogram.png"
    alt="Devalok"
    style="height: 52px; width: auto; margin: 0 auto;"
  />
  <div style="width: 1px; height: 32px; background-color: #e0e0e0; margin: 20px auto;"></div>
  <p style="font-family: 'Inter', Arial, sans-serif; font-size: 11px; font-weight: 500; letter-spacing: 2px; text-transform: uppercase; color: #999; margin: 0;">
    <span style="color: #D33163;">Sankalan</span> · Issue 07 · December 2025
  </p>
</div>
```

---

### Email Footer (Deep Pink)

```html
<div style="background-color: #712846;">
  <!-- Footer Top -->
  <div style="padding: 40px 48px; text-align: center;">
    <img
      src="https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/PNG/WHITE/WHITE%20-%20Monogram.png"
      alt="Devalok"
      style="height: 48px; width: auto; margin: 0 auto 24px;"
    />
    <p style="font-family: 'Inter', Arial, sans-serif; font-size: 11px; font-weight: 600; letter-spacing: 3px; text-transform: uppercase; color: #ffffff; margin: 0 0 8px 0;">Devalok</p>
    <p style="font-family: 'Playfair Display', Georgia, serif; font-size: 14px; font-style: italic; color: #EFD5D9; margin: 0 0 32px 0;">Design and Strategy Studio</p>

    <!-- Social Icons -->
    <div style="margin: 24px 0;">
      <a href="https://behance.net/devalok" style="display: inline-block; margin: 0 12px;">
        <img src="https://cdn.jsdelivr.net/gh/simple-icons/simple-icons/icons/behance.svg" alt="Behance" style="width: 18px; height: 18px; filter: invert(1);">
      </a>
      <a href="https://linkedin.com/company/devalok/" style="display: inline-block; margin: 0 12px;">
        <img src="https://cdn.jsdelivr.net/gh/simple-icons/simple-icons/icons/linkedin.svg" alt="LinkedIn" style="width: 18px; height: 18px; filter: invert(1);">
      </a>
      <a href="https://youtube.com/@devalokstudio" style="display: inline-block; margin: 0 12px;">
        <img src="https://cdn.jsdelivr.net/gh/simple-icons/simple-icons/icons/youtube.svg" alt="YouTube" style="width: 18px; height: 18px; filter: invert(1);">
      </a>
      <a href="https://x.com/devalokstudio" style="display: inline-block; margin: 0 12px;">
        <img src="https://cdn.jsdelivr.net/gh/simple-icons/simple-icons/icons/x.svg" alt="X" style="width: 18px; height: 18px; filter: invert(1);">
      </a>
    </div>

    <!-- Divider -->
    <div style="width: 40px; height: 1px; background-color: #932044; margin: 24px auto;"></div>

    <!-- Footer Nav -->
    <div style="margin: 24px 0;">
      <a href="https://devalok.in/works" style="display: inline-block; margin: 0 16px; font-family: 'Inter', Arial, sans-serif; font-size: 12px; font-weight: 500; color: #EFD5D9; text-decoration: none;">Work</a>
      <a href="https://devalok.in" style="display: inline-block; margin: 0 16px; font-family: 'Inter', Arial, sans-serif; font-size: 12px; font-weight: 500; color: #EFD5D9; text-decoration: none;">About</a>
      <a href="https://talk.devalok.in" style="display: inline-block; margin: 0 16px; font-family: 'Inter', Arial, sans-serif; font-size: 12px; font-weight: 500; color: #EFD5D9; text-decoration: none;">Contact</a>
    </div>
  </div>

  <!-- Footer Bottom -->
  <div style="padding: 20px 48px; background-color: #612040; text-align: center;">
    <p style="font-family: 'Inter', Arial, sans-serif; font-size: 11px; color: #DD9EB8; margin: 0 0 8px 0;">
      Lucknow, India · Phoenix, Arizona
    </p>
    <p style="font-family: 'Inter', Arial, sans-serif; font-size: 10px; color: #B02651; margin: 0;">
      © 2025 Devalok Design and Strategy Studio Pvt. Ltd.
    </p>
  </div>
</div>
```

---

### Typography Components

#### Headline (H1)
```html
<h1 style="font-family: 'Playfair Display', Georgia, serif; font-size: 28px; font-weight: 500; line-height: 1.3; margin: 0 0 24px 0; color: #1a1a1a;">
  A New Brand Takes Shape
</h1>
```

#### Section Header (H2)
```html
<h2 style="font-family: 'Playfair Display', Georgia, serif; font-size: 22px; font-weight: 500; line-height: 1.35; margin: 48px 0 16px 0; color: #1a1a1a;">
  Behind the Work
</h2>
```

#### Section Label (H3)
```html
<h3 style="font-family: 'Inter', Arial, sans-serif; font-size: 13px; font-weight: 600; line-height: 1.4; margin: 40px 0 20px 0; color: #D33163; text-transform: uppercase; letter-spacing: 1px;">
  What's New
</h3>
```

#### Greeting
```html
<p style="font-family: 'Playfair Display', Georgia, serif; font-size: 24px; font-weight: 400; color: #1a1a1a; margin: 0 0 24px 0;">
  Namaskar,
</p>
```

#### Body Paragraph
```html
<p style="font-family: 'Inter', Arial, sans-serif; font-size: 15px; margin: 0 0 16px 0; color: #333; line-height: 1.7;">
  Your paragraph text here.
</p>
```

---

### Content Components

#### Blockquote
```html
<div style="margin: 32px 0; padding: 24px; background-color: #FCF7F7; border-left: 3px solid #D33163;">
  <p style="font-family: 'Playfair Display', Georgia, serif; font-size: 18px; font-style: italic; line-height: 1.6; color: #1a1a1a; margin: 0 0 8px 0;">
    "Design is not just what it looks like. It's what it holds — the story, the intention, the care."
  </p>
  <span style="font-family: 'Inter', Arial, sans-serif; font-size: 13px; color: #888;">From our philosophy</span>
</div>
```

#### Pull Quote (Centered)
```html
<div style="margin: 48px 0; padding: 32px 0; text-align: center; border-top: 2px solid #F7E9E9; border-bottom: 2px solid #F7E9E9;">
  <p style="font-family: 'Playfair Display', Georgia, serif; font-size: 22px; font-weight: 400; font-style: italic; line-height: 1.5; color: #1a1a1a; margin: 0;">
    "Every brand carries a <span style="color: #D33163;">story worth telling</span>."
  </p>
</div>
```

#### Highlight Box
```html
<div style="margin: 32px 0; padding: 24px; background-color: #FCF7F7; border-left: 3px solid #D33163;">
  <p style="font-family: 'Inter', Arial, sans-serif; font-size: 14px; margin: 0; color: #333; line-height: 1.6;">
    <strong>Coming soon:</strong> A detailed case study on our approach to packaging design.
  </p>
</div>
```

#### Divider
```html
<hr style="height: 1px; background-color: #F7E9E9; margin: 40px 0; border: none;">
```

---

### What's New Feature Item

```html
<div style="background-color: #FCF7F7; margin: 32px -48px; padding: 32px 48px;">
  <!-- Feature Item -->
  <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom: 24px; padding-bottom: 24px; border-bottom: 1px solid #F7E9E9;">
    <tr>
      <td style="width: 56px; vertical-align: top; padding-right: 20px;">
        <div style="width: 44px; height: 44px; background-color: #ffffff; border: 1px solid #F7E9E9; display: flex; align-items: center; justify-content: center; font-size: 20px; color: #D33163; text-align: center; line-height: 44px;">
          ✦
        </div>
      </td>
      <td style="vertical-align: top;">
        <p style="font-family: 'Playfair Display', Georgia, serif; font-size: 18px; font-weight: 500; color: #1a1a1a; margin: 0 0 6px 0;">Team Growth</p>
        <p style="font-family: 'Inter', Arial, sans-serif; font-size: 14px; color: #555; margin: 0; line-height: 1.6;">We welcomed Shriman Visahan to the team as Operations Associate.</p>
        <a href="#" style="display: inline-block; margin-top: 8px; font-family: 'Inter', Arial, sans-serif; font-size: 13px; font-weight: 500; color: #D33163; text-decoration: none;">Learn more →</a>
      </td>
    </tr>
  </table>
</div>
```

---

### Buttons

#### Primary CTA
```html
<a href="https://devalok.in/works" style="display: inline-block; padding: 14px 32px; background-color: #D33163; color: #ffffff; text-decoration: none; font-family: 'Inter', Arial, sans-serif; font-size: 13px; font-weight: 600; letter-spacing: 0.3px;">
  View Our Work
</a>
```

#### Secondary CTA
```html
<a href="https://talk.devalok.in" style="display: inline-block; padding: 12px 28px; background-color: transparent; color: #1a1a1a; text-decoration: none; font-family: 'Inter', Arial, sans-serif; font-size: 13px; font-weight: 600; border: 1px solid #1a1a1a; margin-left: 12px;">
  Start a Conversation
</a>
```

---

### Two-Column Layout

```html
<div style="margin: 32px 0; background-color: #FCF7F7; padding: 24px;">
  <table width="100%" cellpadding="0" cellspacing="0">
    <tr>
      <td style="width: 48%; vertical-align: top; padding-right: 20px;">
        <h4 style="font-family: 'Inter', Arial, sans-serif; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; color: #D33163; margin: 0 0 8px 0;">For Brands</h4>
        <p style="font-family: 'Inter', Arial, sans-serif; font-size: 14px; margin: 0; color: #333; line-height: 1.6;">Building something meaningful? <a href="https://talk.devalok.in" style="color: #D33163;">Book a call →</a></p>
      </td>
      <td style="width: 48%; vertical-align: top; padding-left: 20px; border-left: 1px solid #F7E9E9;">
        <h4 style="font-family: 'Inter', Arial, sans-serif; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; color: #D33163; margin: 0 0 8px 0;">For Creatives</h4>
        <p style="font-family: 'Inter', Arial, sans-serif; font-size: 14px; margin: 0; color: #333; line-height: 1.6;">Looking for a home that values craft? <a href="mailto:pac@devalok.in" style="color: #D33163;">Get in touch →</a></p>
      </td>
    </tr>
  </table>
</div>
```

---

### Image Block

```html
<div style="margin: 32px 0;">
  <img src="IMAGE_URL" alt="Description" style="width: 100%; height: auto; display: block;">
  <p style="font-family: 'Inter', Arial, sans-serif; font-size: 13px; color: #888; margin-top: 12px; font-style: italic;">
    Caption text here
  </p>
</div>
```

---

### Video Block (Thumbnail + Play)

```html
<div style="margin: 32px 0;">
  <a href="VIDEO_URL" style="display: block; position: relative; text-decoration: none;">
    <img src="THUMBNAIL_URL" alt="Video" style="width: 100%; height: auto; display: block;">
    <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 64px; height: 64px; background-color: #D33163; display: flex; align-items: center; justify-content: center;">
      <span style="color: #ffffff; font-size: 24px; margin-left: 4px;">▶</span>
    </div>
  </a>
  <p style="font-family: 'Inter', Arial, sans-serif; font-size: 13px; color: #888; margin-top: 12px;">
    Watch: Video Title · Duration
  </p>
</div>
```

---

### Signature Block

```html
<div style="margin: 48px 0 0 0; padding-top: 32px; border-top: 1px solid #F7E9E9;">
  <p style="font-family: 'Playfair Display', Georgia, serif; font-size: 18px; color: #1a1a1a; margin: 0 0 4px 0;">Mudit Lal</p>
  <p style="font-family: 'Inter', Arial, sans-serif; font-size: 13px; color: #888; margin: 0;">Founder, Devalok</p>
</div>
```

---

### Contact Block

```html
<div style="margin: 32px 0; padding: 20px 24px; background-color: #FCF7F7; text-align: center;">
  <p style="font-family: 'Inter', Arial, sans-serif; font-size: 14px; margin: 0; color: #333;">
    <a href="mailto:hello@devalok.in" style="color: #1a1a1a; font-weight: 500; text-decoration: none;">hello@devalok.in</a> ·
    <a href="tel:+917754850181" style="color: #1a1a1a; font-weight: 500; text-decoration: none;">+91 77548 50181</a>
  </p>
</div>
```

---

### Complete Email Template Structure

See [option-i-deep-pink-footer.html](../email-template-samples/option-i-deep-pink-footer.html) for a complete working example with all components.

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!--[if mso]>
  <style type="text/css">
    body, table, td { font-family: Arial, sans-serif !important; }
  </style>
  <![endif]-->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Playfair+Display:ital,wght@0,400;0,500;0,600;1,400&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, Arial, sans-serif;
      background-color: #f5f5f5;
      margin: 0;
      padding: 0;
    }
    .wrapper { width: 100%; background-color: #f5f5f5; padding: 32px 0; }
    .container { max-width: 640px; margin: 0 auto; background-color: #ffffff; }
  </style>
</head>
<body>
  <div class="wrapper">
    <div class="container">
      <!-- Header (monogram, divider, meta) -->
      <!-- Content (greeting, body, components) -->
      <!-- Footer (deep pink with white branding) -->
    </div>
  </div>
</body>
</html>
```

---

## Web Implementation

### Favicon HTML
```html
<link rel="icon" type="image/png" sizes="32x32" href="https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Favicon/COLOR/PNG/Favicon_COLOR%20%2832%20pt%29.png">
<link rel="icon" type="image/png" sizes="16x16" href="https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Favicon/COLOR/PNG/Favicon_COLOR%20%2816%20pt%29.png">
<link rel="apple-touch-icon" sizes="180x180" href="https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Favicon/COLOR/PNG/Favicon_COLOR%20%28180%20pt%29.png">
```

### Open Graph / Social Meta
```html
<meta property="og:image" content="https://cdn.jsdelivr.net/gh/devalok-design/devalok-brand-assets@main/Logo/PNG/COLOR/COLOR%20-%20Monogram%20%2B%20Wordmark-01-01.png">
```

---

*Reference: assets.md | Version 3.0.0*
