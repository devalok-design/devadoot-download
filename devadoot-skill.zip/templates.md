# Devalok Writing Templates

> Ready-to-use templates for common writing tasks. Sharp, professional, warm.

---

## Opening Guidance

**Not everything needs to start with "Namaskar."**

| Context | Recommended Opening |
|---------|---------------------|
| First contact with new client | Namaskar [Name], |
| Formal proposals or pitches | Namaskar [Name], |
| Casual ongoing communication | Hey [Name], / Hi [Name], |
| Quick updates to established clients | [Name], |
| Internal team messages | Team, / Hey team, |
| Follow-ups | Hope you're doing well, [Name] — |

Use "Namaskar" when it carries meaning: first impressions, formal contexts, and moments that warrant cultural intentionality. For everyday emails with clients you've worked with for months, a simple "Hi" is more authentic than forced formality.

---

## Client Email Templates

### Discovery Call Follow-up

```
Namaskar [Name],

Good speaking with you [yesterday/earlier today]. The clarity you have around [Brand/Project] came through clearly — especially [specific thing they mentioned].

I've been thinking about [specific challenge or opportunity]. Here's what stands out:

[2-3 sentences of initial perspective]

I've attached [proposal/deck/materials]. Let me know what questions come up.

Looking forward to next steps.

[Your name]
```

### Ongoing Project Update

```
Hi [Name],

Quick update on [project element] — I think you'll like where this is heading.

**Completed:**
[Brief description]

**In progress:**
[Brief description]

**Timeline:**
[When they'll see the next deliverable]

[Link to view work if applicable]

Let me know if you'd like to walk through anything together.

[Your name]
```

### After a Delay

```
Hi [Name],

Thanks for your patience. We wanted to get this right before sharing.

[Brief context on what you're sending]

[Link or attachment]

Appreciate you giving us the space to work through this properly. Looking forward to your thoughts.

[Your name]
```

### Sharing Work for Feedback

```
Hi [Name],

Here's the first round of [what you're sharing].

[1-2 sentences on the thinking behind it]

[Link]

Take your time. I'd love to hear what lands and what questions come up. Happy to jump on a call or discuss over email — whatever works.

[Your name]
```

### Responding to Difficult Feedback

```
[Name],

Thank you for the honest feedback. It helps us get closer to what [Brand] actually needs.

Here's how I'm reading your notes:

[Address each point with understanding and direction]

[If you disagree: "I'd like to explore [specific point] further — I think there's an angle we might be missing."]

Let me know if this direction feels right.

[Your name]
```

### Politely Declining a Project

```
Namaskar [Name],

Thank you for reaching out. It means a lot that you thought of Devalok for this.

After considering the scope, we don't think we're the right fit for this one. [Brief, honest reason if appropriate]

[Optional: "I'd suggest reaching out to [alternative] — they'd be a good match for what you're looking for."]

Hope our paths cross again in the future.

[Your name]
```

### Following Up (When No Response)

```
Hi [Name],

Just checking in on [project/proposal]. I know things get busy — wanted to make sure my last message didn't slip through.

[Brief reminder of context]

No rush. Happy to continue the conversation whenever you're ready.

[Your name]
```

### Project Kick-off

```
Namaskar [Name],

We're officially underway. Here's what to expect:

**This week:** [First milestone]
**Your next touchpoint:** [Date/stage]
**If you need us:** [Preferred contact method]

Excited to get started.

[Your name]
```

### Milestone Delivery

```
[Name],

[Deliverable] is ready.

[Link]

[1-2 sentences on what you're sending and key decisions made]

Let me know your thoughts — I'm around [days/times] for a call if that helps.

[Your name]
```

### Project Completion

```
[Name],

It's been a pleasure working on [Project]. Everything is wrapped:

**Delivered:**
- [Final deliverable 1]
- [Final deliverable 2]
- [Final deliverable 3]

[Link to final assets/handoff]

Thank you for the trust throughout this process. We're proud of what this has become.

[Your name]
```

---

## Proposal Templates

### Proposal Opening

```
Namaskar [Name],

You're not just building a [product/service]. You're building [deeper vision or meaning].

That's what came through in our conversation. And it's what makes this project worth doing well.

[Brand] has [context about their journey]. What stood out to us was [specific insight from discovery]. That's where the opportunity is.
```

### Framing the Opportunity

```
## The Opportunity

The problem isn't [surface issue].

It's [deeper challenge].

[Brand] deserves more than [generic approach]. You need [specific outcome] — something that [meaningful impact].

That's where we come in.
```

### Scope Section

```
## What We'll Do

**Phase 1: [Phase Name]** — [X weeks]
[2-3 bullet points describing deliverables]

**Phase 2: [Phase Name]** — [X weeks]
[2-3 bullet points describing deliverables]

**Phase 3: [Phase Name]** — [X weeks]
[2-3 bullet points describing deliverables]

Total timeline: [X weeks/months]
```

### Investment Section

```
## Your Investment

**Total:** ₹X,XX,XXX

This includes:
- [Scope item 1]
- [Scope item 2]
- [Scope item 3]

**Payment:**
- 50% to begin
- 50% upon completion

**Timeline:** [X weeks/months]

This sets [Brand] up for [meaningful outcome].
```

### Proposal Closing

```
## Why Devalok

We don't work like vendors. We work like partners.

What sets us apart:
- We craft end-to-end — from strategy to production
- We work in-house — one team, no silos
- We push beyond the brief when we see potential

The next step is a conversation. Let's talk.

With warmth,
The Lokwasis
```

---

## Social Media Templates

### LinkedIn: Insight Post

```
[Hook — surprising insight or question]

[2-3 short paragraphs developing the idea]

[Closing thought that sticks]

#branding #design #strategy
```

**Example:**

```
A logo is a doorway, not the house.

When we work with a brand, we don't start with shapes and colors. We start with questions: What does this stand for? Who does it serve? What should people feel?

Those answers shape everything — the typography, the tone, the entire visual system.

Design without intention is decoration. Design with intention is presence.

#branding #design #devalok
```

### LinkedIn: Work Announcement

```
New work: [Project Name]

[1-2 sentences about the brand and their journey]

[What made this project meaningful to work on]

[Link or "More in comments"]

Thank you to [Client] for the trust.

#newwork #branding #design
```

### Instagram: Caption (Short)

```
[One sharp or poetic line about the work]

[Brand name or context if needed]

.
.
.
#devalok #branding #design
```

### Instagram: Caption (Process)

```
The work you see is never just the work.

[1-2 sentences about what went into it]

[Why it matters]

.
.
.
#devalok #designprocess #behindthework
```

---

## Case Study Templates

### Opening

```
[Client] came to us looking for more than a [logo/identity/website]. They needed a way to tell their story.

Founded in [year/context], [Brand] had grown from [origin] to [current state]. But the visual presence hadn't kept up. They needed a foundation that could scale with them.

That's where we started.
```

### The Challenge

```
## The Challenge

[Brand] faced a clear problem:

- [Challenge 1]
- [Challenge 2]
- [Challenge 3]

But beneath these was a deeper question: [strategic question that drives the work].
```

### The Approach

```
## Our Approach

We started with questions.

[Discovery process — workshops, conversations, research]

From there, [creative development process].

Key decisions:
- [Decision 1 and rationale]
- [Decision 2 and rationale]
- [Decision 3 and rationale]
```

### The Impact

```
## The Impact

"[Client quote]"

Since launching, [Brand] has [specific results if available].

More importantly, they now have a visual language that [meaningful outcome].
```

---

## Newsletter (Sankalan) Templates

### Opening

```
Namaskar,

[Personal opening — what's on our mind, what we've been working on]

This month: [brief overview].
```

### Section: Behind the Scenes

```
## Behind the Work

**[Project name]**

[What made this project special — the thinking, the challenges, the decisions]

[Link to full case study if available]
```

### Section: What's New

```
## What's New

**[Update 1 title]**
[1-2 sentences]

**[Update 2 title]**
[1-2 sentences]

**[Update 3 title]**
[1-2 sentences]
```

### Closing

```
Thank you for being here. Every edition is a chance to share a little more of what happens at Devalok — the thinking, the craft, the work.

Until next month,
The Lokwasis
```

**Note:** Do not add the philosophy statement (आत्मतः शिल्पं कृत्वा) to every newsletter. Reserve it for significant editions — year-end, major announcements, or brand-defining moments.

---

## Internal Communication Templates

### Team Update

```
Team — update on [Project]:

**Done:**
- [Item]
- [Item]

**Next:**
- [Item]
- [Item]

**Blocked:**
[Note or "All clear"]

Questions? Let me know.
```

### Sharing Work for Feedback

```
Team,

[Project] is at [stage]. Looking for fresh eyes.

[Link]

Specifically:
- [Area 1]
- [Area 2]

No rush — whenever you have time.
```

### Celebrating a Win

```
Team,

[What happened]

[Brief context]

Credit to [names] for [contributions].

This is what [principle in action] looks like.
```

### Quick Heads-Up

```
Heads up — [thing to be aware of].

[1-2 sentences of context]

[Action needed if any]
```

---

## Quality Checklists

### Client Emails

- [ ] Opening appropriate to relationship (not always "Namaskar")
- [ ] Name spelled correctly
- [ ] References something specific to them
- [ ] Ask or update is clear
- [ ] Next steps defined
- [ ] Sign-off matches the tone
- [ ] Proofread

### Proposals

- [ ] Leads with their story, not ours
- [ ] Opportunity framed from their perspective
- [ ] Investment positioned as partnership
- [ ] Next steps are clear
- [ ] Feels like invitation, not pitch
- [ ] No excessive signature phrases

### Social Media

- [ ] Offers genuine value or insight
- [ ] No promotional language
- [ ] Ends with something resonant
- [ ] Represents the studio well

### Case Studies

- [ ] Opens with client's journey
- [ ] Shows thinking, not just output
- [ ] Client voice included
- [ ] Visuals lead the story
- [ ] Documentary tone

### Newsletters

- [ ] Personal opening
- [ ] Value in every section
- [ ] Philosophy statement used sparingly (if at all)
- [ ] Clear and scannable

---

*Reference: templates.md | Version 3.0.0*
