# Devalok Client Guide

> **आत्मतः शिल्पं कृत्वा** — "From the soul, we craft."

This file covers ideal client profile, services, process, and how to talk about Devalok.

---

## How to Talk About Devalok

### The Short Version (One Line)

> "We're a design and strategy studio that helps thoughtful brands tell their story and build their presence — from identity and packaging to websites and beyond."

### The Medium Version (Paragraph)

> "Devalok is a design and strategy studio that works with founders who care about meaning. We don't just design logos or websites — we build entire brand ecosystems, from strategy to manufacturing. Our philosophy is 'From the soul, we craft' — we see ourselves as partners in bringing meaningful ideas to life."

### When Asked "What Makes You Different?"

> "Three things:
>
> First, **we craft the whole** — not just the logo or the website, but the entire ecosystem, including helping with manufacturing and supply chains.
>
> Second, **we do it all in-house** — our team of designers, writers, and strategists work as one unit, no silos.
>
> Third, **we go beyond the brief** — when we see potential, we push further. We're not vendors checking boxes. We're partners invested in your success."

---

## Ideal Client Profile

### Who We Work Best With

| Quality | Description |
|---------|-------------|
| **Thoughtful founders** | Building something meaningful, not just chasing profit |
| **Good intent** | Projects that positively impact society |
| **Open to depth** | Willing to go through a real process, not just a transaction |
| **Story-driven** | Have something worth saying and care how it's said |
| **Craft-appreciators** | Value quality, detail, and intention over speed and shortcuts |
| **Partnership-minded** | See Devalok as collaborators, not vendors |

> "Bold enough to lead, thoughtful enough to care."

### Stage Fit

| Stage | Fit |
|-------|-----|
| **Early-stage startups** | Ready for GTM (go-to-market) |
| **Growing brands** | Ready to professionalize their identity |
| **Legacy brands** | Ready for thoughtful refresh |

### Not a Fit

| Type | Why Not |
|------|---------|
| Only optimizing for lowest cost | We invest in quality, not speed |
| Unwilling to invest in process | Our process creates lasting results |
| No positive societal intent | We work with brands doing good |
| See design as decoration | We see design as strategy |
| Want "just a logo" | We build ecosystems |
| Don't value collaboration | Our process is partnership-based |

---

## Services

### Brand Story & Visual Identity

- Brand Name / Rename
- Brand Philosophy & Voice
- Logo Design
- Typography & Colors
- Patterns & Illustrations
- Motion Identity
- Brand Mockups & Guidelines

### Packaging Design

- Dieline & Structural Design
- Information Hierarchy
- Variant Expression
- Material Selection
- Closure Systems
- Production Coordination

### Print & Event Design

- Editorial Design
- Marketing Collaterals
- Event Branding
- Signage & Wayfinding
- Spatial Graphics
- Customized Print

### UI/UX Design

- Information Architecture
- User Flow & Journey
- Visual System
- Core UI Elements
- Responsive Design
- Prototyping & Handoff

### Production Network

- Manufacturing partnerships
- Supply chain setup
- Operational consulting

### Production Partners

| Partner | Specialty | Location |
|---------|-----------|----------|
| ASU Print and Imaging Lab | Print | Phoenix, Arizona |
| MOO | Premium print | Rhode Island, USA |
| Bajaj Copiers & Printers | Print | Lucknow, India |
| WLBS | Website/product development | India |
| Dpotli | Handcrafted products, packaging | Rajasthan, India |
| Maév Overseas | Garment production | Uttar Pradesh, India |

---

## The Five-Stage Process

### Stage 1: Discovery Call

> Every partnership begins with a conversation.

**What happens:**
- Mudit holds the first call
- Walks through Deck 01 (philosophy, past work, why branding matters)
- Understands client's business, goals, needs
- Checks for creative and cultural alignment
- Identifies non-negotiables

**After the call (if aligned):**
- Deck shared with client
- Custom proposal with investment and rough timeline
- Client confirms partnership

**Key phrase:** "We meet to exchange questions, listen openly, and share expectations. You leave with a clear sense of whether we're the right fit."

### Stage 2: Onboarding & Brand Workshop

> We welcome you into our process with a workshop designed for your brand.

**What happens:**
- Project lead and co-lead assigned
- Custom brand workshop prepared (Deck 02)
- Workshop conducted via FigJam
- Team introductions on both sides
- Goals and objectives clarified
- Phase-wise timeline deck shared (Deck 03)

**Key phrase:** "Together, we dive deep into its story, values, and creative direction."

### Stage 3: Creative Development

> With a strong foundation in place, we begin exploring ideas.

**What happens:**
- Concept development
- Design explorations
- Client feedback rounds
- Iteration and refinement

**Key phrase:** "Concepts are developed, tested, and refined with your feedback at every step."

### Stage 4: Brand Applications

> A brand comes alive only when it reaches people across touchpoints.

**What happens:**
- Identity extended across touchpoints
- Website, packaging, campaigns, experiences
- Brand ecosystem completion

**Key phrase:** "This ensures you have a brand ecosystem that works seamlessly wherever it shows up."

### Stage 5: Official Brand Launch

> The launch is the moment your brand meets its audience for the first time.

**What happens:**
- All assets prepared
- Platforms and channels ready
- Complete, consistent rollout

**Key phrase:** "You step forward with a presence that is distinct, memorable, and ready to grow."

---

## Evaluating Client Fit

### Questions to Consider

| Question | Good Sign | Red Flag |
|----------|-----------|----------|
| Why do they need this now? | Clear vision, meaningful timing | "Just want something new" |
| How do they talk about their brand? | With passion and clarity | As a checkbox |
| What's their timeline expectation? | Reasonable, flexible | "Need it yesterday" |
| How do they respond to questions? | Thoughtfully, openly | Defensively, dismissively |
| What's their budget conversation like? | Investment mindset | "What's the cheapest?" |

### Good Client Signals

- Asks thoughtful questions about our process
- Has done homework on Devalok
- Talks about meaning and impact, not just aesthetics
- Is willing to participate in workshops
- Values collaboration and partnership
- Has realistic timeline expectations

### Red Flag Signals

- Focused only on price
- Wants to skip the process
- Has unrealistic timelines
- Doesn't see value in strategy
- Treats designers as order-takers
- Has no clear vision or direction

---

## Client Communication Standards

### The 24-Hour Rule

> No client communication goes unanswered for more than 24 hours.

Even if you don't have an answer yet:
> "Thank you for your message — I'm looking into this and will get back to you by [specific time]."

### Communication Principles

| Principle | Application |
|-----------|-------------|
| **Prompt** | Respond within 24 hours, always |
| **Clear** | No ambiguity in what's being asked or shared |
| **Complete** | Don't leave questions unanswered |
| **Warm** | Even routine updates should feel human |
| **Quality** | Everything shared reflects well on Devalok |

### Keeping Clients Updated

| Situation | Action |
|-----------|--------|
| Timeline shift | Proactive communication before deadline |
| Waiting for feedback | Gentle check-in after 3-5 days |
| Significant progress | Share excitement, don't wait for formal review |
| Problem or delay | Honest communication with proposed solution |

---

## Notable Clients & Projects

*(Reference for context, not for unsolicited promotion)*

- DIVINI
- Kaizen Waste
- Eat Purposefully
- Bondle
- MoveCars.com
- Enchanted Baby
- Arculis
- Chandler Sister Cities
- NEETI
- Coffee Plantation
- Infinity Mind Movies
- ASU (Arizona State University)

---

## Media Features

- Packaging of the World
- World Brand Design Society
- Creative Gaga

---

## Proposal Mindset

### Never Pitch. Partner.

A proposal is not a sales document. It's the beginning of a conversation about what we'll create together.

**The client should feel:**
- Understood, not sold to
- Excited, not pressured
- Clear on what happens next

### Proposal Tone

- Confident but not boastful
- Visionary but grounded
- Thorough but not overwhelming

### Proposal Structure

1. **Their Story First** — Show we listened
2. **What We See** — Our perspective on the opportunity
3. **How We'll Approach It** — The process, not just deliverables
4. **What We'll Create Together** — Framed as partnership
5. **Investment** — Never say "cost" — this is an investment
6. **Why Devalok** — Brief, let work speak

---

## NDA & Confidentiality

### Default Behavior

Treat all client information as confidential unless explicitly told it's public.

### When a Project is Under NDA

- Do not reference the project by name
- Do not share details, learnings, or specifics
- If asked for examples, offer non-NDA alternatives
- When NDA period ends, you'll be informed

### What's Generally Public

- Projects featured on devalok.in/works
- Case studies published on Behance
- Work featured in media
- Client testimonials that have been shared

**When in doubt, ask.**

---

*Reference: clients.md | Version 2.0.0*
