# Devalok Glossary

> **आत्मतः शिल्पं कृत्वा** — "From the soul, we craft."

This file contains all Devalok-specific terminology, Sanskrit/Hindi terms, and their meanings.

---

## Core Terms

| Term | Script | Meaning |
|------|--------|---------|
| **Devalok** | देवलोक | The celestial realm; place of creation, sustenance, and re-creation. The studio's name representing where ideas are born and transformed. |
| **Devadoot** | देवदूत | Divine messenger; the AI assistant that carries Devalok's voice. Literally "one who carries the message of the divine realm." |
| **Lokwasi** | लोकवासी | Inhabitant of the Lok; what Devalok team members are called. |
| **आत्मतः शिल्पं कृत्वा** | — | "From the soul, we craft" — Devalok's core philosophy statement. |
| **Padmavarna** | पद्मवर्ण | "Lotus color" — the official Devalok pink (#D33163). Registered at color-register.org. |

---

## Publications & Systems

| Term | Script | Meaning |
|------|--------|---------|
| **Lokgranth** | लोक ग्रंथ | "Book of the Lok" — Devalok's internal team handbook containing operating principles and culture. |
| **Karyakram** | कार्यक्रम | "Program/Plan" — Project recordkeeping document; single source of truth for every project. |
| **Karm** | कर्म | "Action/Work" — Attendance and payroll tracking system at karm.devalok.in. |
| **Sahayak** | सहायक | "One who helps" — Client handbook given to every client. |
| **Manas** | मानस | "Mind/Heart" — Portfolio book containing stories, process, and thinking behind Devalok's work. |
| **Sankalan** | संकलन | "Collection/Compilation" — Devalok's monthly newsletter. |

---

## Events & Initiatives

| Term | Script | Meaning |
|------|--------|---------|
| **Lokutsav** | लोकउत्सव | "Festival of the Lok" — Annual birth anniversary celebration following the Panchang calendar. |
| **Aabhaar** | आभार | "Gratitude" — Client appreciation events. "Tonight isn't about business, it's about the people in this room." |
| **Gurukul** | गुरुकुल | Traditional school/learning place — Devalok Gurukul is the design education initiative. |

---

## Greetings & Communication

| Term | Script | Meaning |
|------|--------|---------|
| **Namaskar** | नमस्कार | Traditional greeting meaning "I bow to the divine in you." Standard greeting across Devalok communications. |
| **Panchang** | पंचांग | Traditional Hindu lunar calendar used for determining Lokutsav dates. |

---

## Roles

| Term | Meaning |
|------|---------|
| **ADA** | Assistant Design Associate — Works independently, understands process |
| **DA** | Design Associate — Expert in one area, mentors others |
| **DD** | Design Director — Provides creative direction across teams |
| **PAC** | People and Culture — HR/team operations department |

---

## Philosophy & Symbolism

| Term | Script | Meaning |
|------|--------|---------|
| **Gyan Mudra** | ज्ञान मुद्रा | Hand gesture of knowledge (thumb and index finger touching). Featured in Devalok's logo. |
| **Alta** | आलता | Bright red dye applied to fingertips and palm. Represents purity and divine feminine energy. |
| **Trimurti** | त्रिमूर्ति | The three forms: Brahma (creator), Vishnu (sustainer), Shiv (destroyer/creator of space). |
| **Svadhisthana** | स्वाधिष्ठान | The creativity chakra. The six-petaled flower in the logo is derived from this. |
| **Brahman** | ब्रह्मन् | The ultimate reality/source in Hindu philosophy. The higher source from which creativity flows. |
| **Shakti** | शक्ति | Divine feminine energy. Paired with Shiv to represent the two aspects of the universe. |

---

## Design Terms

| Term | Meaning |
|------|---------|
| **Padmavarna** | The Devalok pink: #D33163 |
| **Monogram** | The icon-only version of the Devalok logo (hand with lotus) |
| **Shell** | Circular container around the monogram |
| **Coin** | Alternate circular container style |
| **Wordmark** | The "DEVALOK" text logo |
| **DASS** | "Design and Strategy Studio" — alternate wordmark |
| **SHLOKA** | Sanskrit verse wordmark version |

---

## Process Terms

| Term | Meaning |
|------|---------|
| **Discovery Call** | First conversation with potential client |
| **Brand Workshop** | Deep-dive session into brand story, values, and direction |
| **Deck 01** | Philosophy and overview presentation |
| **Deck 02** | Custom brand workshop presentation |
| **Deck 03** | Phase-wise timeline presentation |

---

## Philosophical Concepts

| Concept | Meaning in Devalok Context |
|---------|---------------------------|
| **"From the soul, we craft"** | Recognizing that creativity flows from a higher source; individuals are conduits |
| **"Different by Design"** | Devalok's positioning — intentionally different from traditional agencies |
| **"The Three Pillars"** | Craft the Whole, Do It All In-House, Go Beyond the Brief |
| **"Mediums, not masters"** | Philosophy of humility — we don't create, we channel |
| **"For the Lokwasis, by the Lokwasis"** | Internal motto about team-first culture |

---

## The 14 Loks

The 14 leaves in the logo represent the 14 realms of Vedic cosmology:

**Upper Realms (7):**
1. Satya-loka
2. Tapa-loka
3. Jana-loka
4. Mahar-loka
5. Svar-loka
6. Bhuvar-loka
7. Bhu-loka (Earth)

**Lower Realms (7):**
8. Atala
9. Vitala
10. Sutala
11. Talatala
12. Mahatala
13. Rasatala
14. Patala

---

## Usage Guidelines

### When to Explain Terms

| Audience | Approach |
|----------|----------|
| **Indian clients** | Use terms naturally, no explanation needed |
| **Internal team** | Use freely |
| **International clients** | Explain on first use, use sparingly |
| **Public content** | Brief explanation in parentheses or as footnote |

### Example Explanations

> "We call our client handbook *Sahayak* — meaning 'one who helps.'"

> "This is *Aabhaar*, our evening of gratitude."

> "Our philosophy, *आत्मतः शिल्पं कृत्वा*, translates to 'From the soul, we craft.'"

### Rule

Never force Hindi/Sanskrit for decoration. Use only when it carries meaning or creates connection.

---

## Pronunciation Guide

| Term | Pronunciation |
|------|---------------|
| Devalok | day-vuh-LOKE |
| Devadoot | day-vuh-DOOT |
| Lokwasi | loke-VAH-see |
| Namaskar | nuh-muh-SKAR |
| Padmavarna | pud-muh-VAR-nuh |
| Aabhaar | aa-BHAAR |
| Sankalan | sun-kuh-LUN |
| Sahayak | suh-HAA-yuk |
| Karyakram | kar-ya-KRAM |
| Lokgranth | loke-GRUNTH |
| Lokutsav | loke-UT-suv |
| Svadhisthana | svaa-dhish-THAA-nuh |

---

*Reference: glossary.md | Version 2.0.0*
