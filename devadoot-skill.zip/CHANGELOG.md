# Devadoot Skill Changelog

All notable changes to the Devadoot skill are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/), and this project adheres to [Semantic Versioning](https://semver.org/).

---

## [4.1.4] - 2025-12-28

### Changed
- Simplified version display (removed auto-fetch due to Claude Projects limitations)
- Now shows version badge with manual update link on first response
- Cleaner, error-free version awareness

---

## [4.1.3] - 2025-12-28

### Changed
- Deploy to separate public repo (devadoot-download) keeping main repo private
- Direct download link: github.com/devalok-design/devadoot-download/raw/main/devadoot-skill.zip
- Version check now fetches from public repo

---

## [4.1.2] - 2025-12-28

### Added
- GitHub Actions workflow for automated releases
- Auto-build and release on every push to main

### Changed
- All download links now point to GitHub Releases page
- Simplified update workflow: just `git push` from VS Code

---

## [4.1.1] - 2025-12-28

### Changed
- Improved version check protocol with graceful fallback
- Now displays version badge when web fetch unavailable
- Added explicit GitHub URLs to versions.md for manual checking

---

## [4.1.0] - 2025-12-28

### Added
- **Automatic version check** — Runs on every session start
- **latest-version.md** — Remote version file hosted on GitHub for version comparison
- Smart update notifications based on query domain relevance

### Changed
- SKILL.md now includes automatic version check protocol
- Version check fetches from GitHub raw URL to compare local vs remote versions

---

## [4.0.0] - 2025-12-28

### Added
- **versions.md** — Version manifest with query domain mapping for smart update detection
- **core.md** — Essential identity, contact info, and philosophy (extracted from SKILL.md)
- **CHANGELOG.md** — This file, tracking all changes with semantic versioning
- Version awareness protocol in SKILL.md
- Query domain reference for file routing
- Version check command ("devadoot version")
- Social media URLs added to core.md (Behance, LinkedIn, X, YouTube)
- Founder bio with ASU graduation info
- Services URL (dvlk.in/services)

### Changed
- SKILL.md restructured to focus on instructions (identity info moved to core.md)
- Bumped overall skill version to 4.0.0
- Updated file reference table to include core.md and versions.md

### Fixed
- Team roster now includes full name "Goutham H M"
- Synced contact information between modular files and master document

---

## [3.0.0] - December 2025

### Added
- Initial modular skill structure with 9 markdown files
- SKILL.md as main entry point
- voice.md, brand.md, assets.md, clients.md, operations.md, hiring.md, templates.md, glossary.md

### Notes
- First version of modular skill architecture
- All content files at v2.0.0

---

## [2.0.0] - December 2025

### Changed
- Major content updates across all files
- Refined voice and tone guidelines
- Updated team roster

---

## [1.0.0] - 2024

### Added
- Initial Devadoot skill creation
- Basic brand guidelines and voice documentation

---

## How to Read This Changelog

- **Added** — New features or content
- **Changed** — Updates to existing features or content
- **Fixed** — Bug fixes or corrections
- **Removed** — Features or content that were removed
- **Deprecated** — Features that will be removed in future versions

---

*Maintained by the Lokwasis of Devalok Design and Strategy Studio*
