# Devalok Core Identity

> **आत्मतः शिल्पं कृत्वा** — "From the soul, we craft."

This file contains essential identity information, contact details, and company overview.

---

## Quick Reference

| Element | Value |
|---------|-------|
| **Legal Name** | Devalok Design and Strategy Studio Pvt. Ltd. |
| **Type** | Private Limited Company |
| **Founder** | Mudit Lal |
| **Founded** | 23 August 2024 |
| **Greeting** | Namaskar (नमस्कार) |
| **Primary Color** | #D33163 (Devalok Padmavarna) |
| **HTML & UI Font** | Inter |
| **Philosophy** | आत्मतः शिल्पं कृत्वा |
| **Positioning** | "Different by Design" |
| **Team Name** | The Lokwasis (लोकवासी) |
| **Website** | devalok.in |

---

## The Name: Devalok (देवलोक)

In Hindu philosophy, **Devalok** is the celestial realm where ideas take birth, blossom, and mature into completion — where they can give birth to new ideas. This eternal cycle of creation, sustenance, and transformation (Brahma, Vishnu, Shiv) is the foundation of the studio's identity.

---

## Core Philosophy

> "We believe we are mediums of expression for the universe to bring its best ideas to life. This philosophy ensures we never carry the ego of 'I created this' but rather stay forever humble."

### The Three Pillars

| Pillar | Description |
|--------|-------------|
| **We Craft The Whole** | Entire design ecosystems from strategy to manufacturing |
| **We Do It All In-House** | One multidisciplinary team, no silos |
| **We Go Beyond the Brief** | Partners who push when potential exists |

### Philosophy Statements

> "The universe is always in motion — creating, sustaining, evolving. We see design as part of that rhythm: a cycle of refinement where ideas take shape, fall apart to make space for new ones, and return in their strongest form."

> "To craft is to engage with both the self and the world, to listen closely, to question deeply, and to push beyond what is known in pursuit of something meaningful. This is the spirit that shapes our practice at Devalok, where soul, intention, and execution intersect."

> "Design, for us, is never just about how something looks — it's about what it holds. A moment to go deeper, understand your vision better, and create something that truly resonates with you and your audience."

---

## Locations

### Headquarters
**Address:** FF – 55, Khazana Market, Aashiana, near Bangla Bazaar, Lucknow – 226012, Uttar Pradesh, Bharat (India)

### US Operations
**Location:** Phoenix, Arizona, USA

---

## Contact Information

### Digital Presence

| Purpose | URL |
|---------|-----|
| **Main Website** | devalok.in |
| **Portfolio** | devalok.in/works |
| **Services** | dvlk.in/services |
| **Booking/Discovery Calls** | talk.devalok.in |
| **Break Framework** | tbf.devalok.in |
| **Karm (Attendance)** | karm.devalok.in |
| **Short URL Pattern** | dvlk.in/[project] |

### Social Media

| Platform | URL |
|----------|-----|
| **Behance** | behance.net/devalok |
| **LinkedIn** | linkedin.com/company/devalok/ |
| **X (Twitter)** | x.com/devalokstudio |
| **YouTube** | youtube.com/@devalokstudio |

### Email Addresses

| Purpose | Address |
|---------|---------|
| **General** | hello@devalok.in |
| **Newsletter** | sankalan@devalok.in |
| **People & Culture** | pac@devalok.in |
| **Founder Direct** | mudit@devalok.in |

### Phone Numbers

| Location | Number |
|----------|--------|
| **India** | +91 77548 50181 |
| **USA** | +1 (602) 693 2521 |

---

## About the Founder

**Mudit Lal** is the Founder & Managing Director of Devalok Design and Strategy Studio.

- Graduated from **Arizona State University** (December 2025)
- Based between Lucknow, India and Phoenix, Arizona, USA
- Leads discovery calls and major client relationships
- Signs off as "Founder" in communications

---

## Signature Phrases

Use these when contextually appropriate:

- "From the soul, we craft."
- "Different by Design"
- "Soulful craft"
- "Design that holds meaning"
- "A brand is a living presence"
- "Soul, intention, and execution intersect"
- "Everything starts with a CONVERSATION. A conversation leads to UNDERSTANDING. And understanding leads to CREATION."
- "For the Lokwasis, by the Lokwasis" *(internal only)*

---

*Reference: core.md | Version 1.0.0*
