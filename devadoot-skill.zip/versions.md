# Devadoot Version Manifest

> Version tracking for the Devadoot skill and all content files.

---

## Overall Skill Version: 4.2.0

**Last Updated:** 2025-12-28

---

## Content File Versions

| File | Version | Updated | Query Domains |
|------|---------|---------|---------------|
| SKILL.md | 4.2.0 | 2025-12-28 | identity, general, devalok, help |
| core.md | 1.0.0 | 2025-12-28 | identity, contact, philosophy, about, founder |
| voice.md | 2.1.0 | 2025-12-28 | writing, email, communication, tone, draft, greeting |
| brand.md | 2.0.0 | 2025-12-28 | design, visual, colors, typography, logo, pattern |
| assets.md | 3.0.0 | 2025-12-28 | logo_urls, favicon, html_email, cdn, assets, images |
| clients.md | 2.0.0 | 2025-12-28 | proposal, client, services, process, discovery, nda |
| operations.md | 2.1.0 | 2025-12-28 | team, internal, systems, breaks, feedback, culture |
| hiring.md | 2.0.0 | 2025-12-28 | hiring, recruitment, onboarding, job_post, hr, interview |
| templates.md | 3.0.0 | 2025-12-28 | template, draft, email_template, social_media, case_study |
| glossary.md | 2.0.0 | 2025-12-28 | terminology, sanskrit, hindi, definition, meaning, pronunciation |

---

## Query Domain Reference

When a user's query matches these domains, reference the corresponding file(s):

| Query Type | Primary File(s) | Secondary File(s) |
|------------|-----------------|-------------------|
| **Identity/About Devalok** | core.md | SKILL.md |
| **Writing emails, proposals** | templates.md, voice.md | clients.md |
| **Design/brand questions** | brand.md | assets.md |
| **HTML emails, logo URLs** | assets.md | brand.md |
| **Client process, services** | clients.md | voice.md |
| **Team/internal operations** | operations.md | core.md |
| **Hiring, job posts** | hiring.md | voice.md |
| **Terminology questions** | glossary.md | — |

---

## How to Check for Updates

**Download Latest:** https://github.com/devalok-design/devadoot-download/raw/main/devadoot-skill.zip

**To update:**
1. Click the download link above
2. Re-upload `devadoot-skill.zip` to your Claude Project

---

## Version Awareness Protocol

When responding to queries:

1. **Identify query domain** — Match the user's request to the query domains above
2. **Check relevant files** — Only consider versions of files that matter for this query
3. **Note if stale** — If the query touches frequently-changing content (team, processes), mention the version date

**Example:**
> "Based on my operations.md (v2.1.0, updated 2025-12-28), the current team includes 13 Lokwasis..."

---

## Version Check Command

When the user says **"devadoot version"** or **"check versions"**, respond with:

```
Devadoot Skill Version: [skill_version]
Last Updated: [last_updated]

Content Modules:
- SKILL.md: v[version]
- core.md: v[version]
- voice.md: v[version]
- brand.md: v[version]
- assets.md: v[version]
- clients.md: v[version]
- operations.md: v[version]
- hiring.md: v[version]
- templates.md: v[version]
- glossary.md: v[version]

To update: Re-upload the latest devadoot-skill.zip to your Claude Project.
```

---

*Reference: versions.md | Version 1.0.0*
