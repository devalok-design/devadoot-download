# Devalok Brand Guidelines

> **आत्मतः शिल्पं कृत्वा** — "From the soul, we craft."

This file defines Devalok's visual identity, colors, typography, and design principles.

---

## Quick Reference

| Element | Value |
|---------|-------|
| **Primary Color** | #D33163 (Devalok Padmavarna) |
| **Display Font** | Moret |
| **Print/Brand Font** | Bricolage Grotesque |
| **HTML & UI Font** | Inter |
| **Type Scale** | Major Third |
| **Pattern** | Six-pointed star tessellation |

---

## Primary Brand Color

### Devalok Padmavarna

**Hex:** `#D33163`

**Meaning:** "Padmavarna" means "lotus color" — the soul color of Devalok.

**Registered at:** color-register.org/color/devalok-padmavarna

**Usage Guidelines:**
- Use purposefully for emphasis, accents, and brand moments
- NOT for large backgrounds
- NOT for body text
- Primary CTAs, key highlights, brand signatures

---

## Color Primitives

### Pink Scale (Primary)

| Token | Hex | Usage |
|-------|-----|-------|
| Pink 50 | #FCF7F7 | Lightest backgrounds |
| Pink 100 | #F7E9E9 | Subtle backgrounds |
| Pink 200 | #EFD5D9 | Borders, dividers |
| Pink 300 | #DD9EB8 | Hover states |
| Pink 400 | #E26598 | Secondary accents |
| Pink 500 | #F0477B | Strong accents |
| **Pink 600** | **#D33163** | **Primary (Padmavarna)** |
| Pink 700 | #B02651 | Pressed states |
| Pink 800 | #932044 | Deep accents |
| Pink 900 | #712846 | Dark accents |
| Pink 950 | #3F181E | Dark mode surfaces |
| Pink 995 | #120C0C | Dark mode backgrounds |
| Pink 1000 | #0C0808 | Deepest dark |

### Purple Scale

| Token | Hex |
|-------|-----|
| Purple 50 | #F8F6FC |
| Purple 100 | #F2EFF8 |
| Purple 200 | #E6E1F3 |
| Purple 300 | #D3C8EA |
| Purple 400 | #AB9DED |
| Purple 500 | #9E7DC9 |
| Purple 600 | #946ABD |
| Purple 700 | #8258A9 |
| Purple 800 | #6D498E |
| Purple 900 | #5A3D75 |
| Purple 950 | #3A274E |
| Purple 955 | #1E1429 |

### Neutrals Scale

| Token | Hex |
|-------|-----|
| Neutral 0 | #FFFFFF |
| Neutral 50 | #F8F7F7 |
| Neutral 100 | #F2F1F1 |
| Neutral 200 | #E6E4E5 |
| Neutral 300 | #D3CED0 |
| Neutral 400 | #B7AFB2 |
| Neutral 500 | #8C8084 |
| Neutral 600 | #6B6164 |
| Neutral 700 | #564E50 |
| Neutral 800 | #403A3C |
| Neutral 900 | #282425 |
| Neutral 950 | #0D0C0C |
| Neutral 1000 | #050505 |

### Blue Scale

| Token | Hex |
|-------|-----|
| Blue 50 | #F1F8FE |
| Blue 100 | #E2F1FC |
| Blue 200 | #BEE2F9 |
| Blue 300 | #84CCF5 |
| Blue 400 | #43B2ED |
| Blue 500 | #1A98DD |
| Blue 600 | #0D79BC |
| Blue 700 | #0C6098 |
| Blue 800 | #0E527E |
| Blue 900 | #114569 |
| Blue 950 | #0C2C45 |

### Semantic Colors

| Purpose | Hex | Usage |
|---------|-----|-------|
| Error | #D2222D | Error states, destructive actions |
| Error Light | #F87179 | Error backgrounds |
| Warning | #E29300 | Warning states |
| Warning Light | #FFF885 | Warning backgrounds |
| Success | #238823 | Success states |
| Success Light | #C3F0C2 | Success backgrounds |
| Information | #43B2ED | Info states |
| Highlight | #9E7DC9 | Highlights, selections |

---

## Typography

### Type Scale
**Scale:** Major Third

### Font Families

| Usage | Font Family | Weight |
|-------|-------------|--------|
| Display/Special | Moret | Regular, Italic |
| UI Titles (H1-H7) | Bricolage Grotesque | Bold |
| Body | Bricolage Grotesque | Regular |
| Labels | Bricolage Grotesque | Medium, All Caps |
| Wordmark | Custom | — |
| Devanagari | Custom | — |

### HTML & UI Font: Inter

For all **HTML emails, web UI, and digital interfaces**, use **Inter** as the primary font family.

| Usage | Font | Weight | Size |
|-------|------|--------|------|
| **Headings (H1)** | Inter | 700 (Bold) | 32px |
| **Headings (H2)** | Inter | 600 (SemiBold) | 24px |
| **Headings (H3)** | Inter | 600 (SemiBold) | 20px |
| **Body Text** | Inter | 400 (Regular) | 16px |
| **Small Text** | Inter | 400 (Regular) | 14px |
| **Labels/Captions** | Inter | 500 (Medium) | 12px |
| **Buttons** | Inter | 600 (SemiBold) | 14-16px |

### CSS Font Stack for HTML/UI

```css
font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
```

### Google Fonts Import

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
```

### Email-Safe Font Stack

For HTML emails where custom fonts may not load:

```css
font-family: 'Inter', Arial, Helvetica, sans-serif;
```

### Application Summary

| Context | Primary Font | Fallback |
|---------|--------------|----------|
| **Print, Presentations** | Moret (display), Bricolage Grotesque (body) | — |
| **HTML Emails** | Inter | Arial, Helvetica |
| **Web UI / Apps** | Inter | System fonts |
| **Brand Guidelines PDF** | Moret, Bricolage Grotesque | — |

### When to Use What

- **Hero text, headlines, special moments** → Moret (print/presentations only)
- **Section headers, titles** → Bricolage Grotesque Bold (print) / Inter SemiBold (digital)
- **Paragraphs** → Bricolage Grotesque Regular (print) / Inter Regular (digital)
- **Labels, captions** → Bricolage Grotesque Medium (print) / Inter Medium (digital)
- **All HTML & UI** → Inter (always)

---

## Logo Components

The Devalok logo contains six sacred components, each rooted in Vedic philosophy:

### 1. Hand of the Universe
- In Gyan mudra (gesture of knowledge and wisdom)
- Alta (bright red dye) on fingertips and palm center
- Blueish-purple tint representing Shiv, Prabhu Shri Ram, and Vishnu
- Represents the two aspects of the universe: Shiv and Shakti

### 2. Lotus of Time
- Three stages: Bud (creation), Flower (sustenance), Seed pod (re-creation)
- Represents Devalok's decision to not participate in predatory industry practices
- Symbolizes time and everything affected by it going through the same stages

### 3. 14 Leaves of the Loks
- The 14 realms (Lokas) of Vedic cosmology
- The 14 Manus ruling each cosmic age (Manvantara)
- The 14 types of knowledge in Vedic texts

### 4. Dots of the Trimurti
- Brahma (creator), Vishnu (sustainer), Shiv (destroyer/creator of space)
- Also represents Orion's Belt (Mrigashira Nakshatra)

### 5. The Sanskrit Inscription
- आत्मतः शिल्पं कृत्वा — "Crafting from the soul"
- Instills humility, purpose, and reverence

### 6. Six-Petaled Svadhisthana Flower
- Derived from Svadhisthana Chakra (creativity chakra)
- Influenced by Maa Sarasvati, goddess of wisdom and creativity

---

## Illustration Style

### Characteristics
- Grainy/textured botanical illustrations
- Lotus flowers in multiple stages (bud, bloom, seed pod)
- Hands in mudras
- Fruits on branches (mangoes, lemons)
- Soft gradients with noise texture
- Color-tinted backgrounds for cards and content

### Pattern
Six-pointed star tessellation derived from the Svadhisthana flower

---

## Design Principles

### When Creating for Devalok

| Principle | Application |
|-----------|-------------|
| **Lead with meaning** | Every element should have a reason to exist. Nothing decorative without purpose. |
| **Embrace texture** | Flat is lifeless. Grain, depth, and tactility create warmth and humanity. |
| **Honor tradition** | Indian aesthetic sensibilities are our foundation. Draw from heritage without cliché. |
| **Balance boldness with restraint** | Be striking, not overwhelming. Know when to push and when to pull back. |
| **Let whitespace breathe** | Space is not empty — it's intentional. Give elements room to speak. |
| **Typography is voice** | Choose and set type as carefully as you write. Type carries tone. |
| **Color with intention** | #D33163 is our soul. Use it purposefully, not everywhere. |

---

## Common Visual Mistakes to Avoid

| ❌ Mistake | ✅ Correct Approach |
|-----------|---------------------|
| Using #D33163 as background | Use as accent, emphasis only |
| Flat illustrations without texture | Add grain, noise, depth |
| Generic stock imagery | Use botanical, hands, meaningful imagery |
| Cluttered layouts | Embrace whitespace |
| Altering logo components | Use approved logo variations only |
| Overusing the pattern | Use pattern sparingly as accent |

---

## Application Contexts

### Light Backgrounds
- Use COLOR or BLACK logo variants
- Primary text: Neutral 900 or 950
- Accents: Pink 600 (#D33163)

### Dark Backgrounds
- Use WHITE logo variants
- Primary text: Neutral 50 or 100
- Accents: Pink 400 or 500

### Digital Applications
- Minimum logo size: 32px height
- Favicon: Use monogram variant
- Social avatars: Use monogram in shell

### Print Applications
- Minimum logo size: 15mm height
- CMYK conversion required
- Consider paper texture in color choices

---

*Reference: brand.md | Version 2.0.0*
