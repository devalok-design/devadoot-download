# Devalok Operations Guide

> **आत्मतः शिल्पं कृत्वा** — "From the soul, we craft."

This file covers team structure, internal systems, culture, and operational processes.

---

## Team Structure

### The Lokwasis (लोकवासी)

Team members at Devalok are called **Lokwasis** — inhabitants of the Lok.

**Core belief:** "For the Lokwasis, by the Lokwasis."

---

## Role Definitions

Roles are responsibilities, not ranks. Leadership is rotational — a DA might lead one project and assist on another.

| Role | Description | Responsibilities |
|------|-------------|------------------|
| **Apprentice** | In training | Learns by doing. Focus on skill-building and exposure to real work. |
| **ADA (Asst. Design Associate)** | Works independently | Understands the right process. Gaining cross-disciplinary experience. |
| **DA (Design Associate)** | Expert in one area | Has cross-disciplinary awareness. Mentors ADAs and fellow DAs. |
| **DD (Design Director)** | Creative direction | Supports multiple teams. Elevates quality and consistency. |
| **Founder** | Sets direction | Steps in when needed, supports overall project health. |

### Specialized Roles

| Role | Focus Area |
|------|------------|
| **Content Associate** | Copywriting, content strategy, brand voice |
| **Operations Associate/Apprentice** | Operations, administration, coordination |
| **US Representative** | US client relations and operations |
| **Director of Stewardship** | People and culture, team operations |

**Important:** Positions are fluid. Cross-training across domains is standard practice.

---

## Current Team

| Name | Role |
|------|------|
| Mudit Lal | Founder & Managing Director |
| Shalini Srivastava | Director of Stewardship |
| Chhavipriya | Design Associate |
| Parth Dake | Design Associate |
| Yogin Naidu | Asst. Design Associate |
| Arundhati Thakur | Content Associate |
| Ayursha Nimse | Asst. Design Associate |
| Goutham H M | Asst. Design Associate |
| Suyash Pingale | Design Apprentice |
| Vidit Lal | Operations Apprentice |
| Bhavika Jain | Design Apprentice |
| Srihitha Jaligama | US Representative |
| Shriman Visahan | Operations Associate |

---

## Operating Principles

### Foundational Rules

| Rule | Why It Matters |
|------|----------------|
| **No one works in a silo. Ever.** | Design grows stronger through multiple perspectives. Isolation may lead to speed, but collaboration leads to depth. |
| **Roles ≠ Hierarchy** | Leadership is based on project needs, not titles. |
| **You are your own manager** | No one tracks your daily work other than yourself. Own your method, your time, your output. |
| **Share early, share ugly** | Don't wait for polish. Sharing work-in-progress opens space for new perspectives. |
| **Talk in the open** | Use group chats, not DMs, for project work. The work becomes better when the room is full. |
| **Acknowledge wins** | Design is never a solo win. Credit collaboration always. "That visual idea came from [Name]'s sketch!" |

### Working Principles

- **Co-create when stuck** — Jump on a short call, do a whiteboard session, ask someone to think it through with you.
- **Document your thought processes** — Add notes, voice recordings, or Loom videos. Keep collaboration async-friendly.
- **Respect quiet zones** — If someone's marked unavailable, don't expect instant responses.
- **Make room for slow days** — Every day won't look the same. Honor creative cycles.
- **Celebrate different ways of thinking** — Some are visual, some are verbal. Let that shape how we work.

---

## Workload Rules

These are firm limits to protect creative energy and ensure quality:

| Limit | Description |
|-------|-------------|
| **Max 2 leads** | No one leads more than 2 active projects at a time |
| **Max 2 co-leads** | No one co-leads more than 2 active projects |
| **Self-regulate** | "Learn to say no, yes, and 'not yet.'" |

If you're overwhelmed, say so. If you have bandwidth, offer help.

---

## Client Communication Standards

These are non-negotiable:

| Standard | Requirement |
|----------|-------------|
| **24-hour rule** | No client communication goes unanswered for more than 24 hours |
| **Quality** | Everything shared with clients reflects high-quality work, even early stages |
| **Clarity** | Replies are prompt, clear, and complete |
| **Conflicts** | Consult the Founder for quick resolution |
| **Delays** | Keep clients updated on timeline shifts due to delays or iterations |

---

## Key Internal Systems

| System | Purpose | Access |
|--------|---------|--------|
| **Karm (कर्म)** | Attendance, breaks, payroll tracking | karm.devalok.in |
| **Karyakram** | Project recordkeeping — single source of truth | Google Docs |
| **Lokgranth (लोक ग्रंथ)** | Internal team handbook | Google Docs |
| **Portal** | Task management and project tracking | Internal |

### About Karyakram

Every project has a Karyakram document — the single source of truth that holds:

- Client info and contacts
- Project goals and objectives
- Meeting recordings and notes
- All project links (Figma, decks, assets)
- Feedback logs
- Timeline and status updates

The Project Lead assigns a record-keeper (or keeps it themselves). Karyakram is updated after every client call, internal check-in, or major decision.

---

## The Break Framework

Devalok provides **122 break days per year** with complete flexibility.

### Calculation

```
52 weeks × 2 weekend days + 15 PTOs + 3 National Holidays = 122 breaks
```

### Key Features

| Feature | Description |
|---------|-------------|
| **No predefined weekends** | Take breaks anytime |
| **Flexibility** | Work continuously, then take extended breaks |
| **Responsibility** | Avoid breaks near project deadlines |
| **Carry forward** | Up to 21 days can carry forward to the next year |
| **Conversion** | Unused days can convert to compensation |

### Notice Requirements

| Break Type | Notice Required |
|------------|-----------------|
| Regular breaks | 2 days advance |
| Extended breaks (5+ days) | 10 days advance |

### National Holidays (Office Closed)

- Republic Day
- Independence Day
- Gandhi Jayanti

### Mid-Year Joiners Formula

```
Number of leaves = (Number of days to December 31 from starting date / 365) × 122
```

**Emergency situations** are handled on a case-by-case basis with understanding.

---

## 2A3B Feedback Framework

When giving or receiving feedback at Devalok:

### The Framework

| Step | Description |
|------|-------------|
| **1. Ask Questions** | Understand the source and thought process before reacting. "What was the intention here?" |
| **2. Acknowledge** | Point out what works and why. Critique isn't just about problems. |
| **3. Be Timely** | Give feedback when it can still shape the outcome. Late feedback is frustrating. |
| **4. Be Specific** | Don't say "this feels off." Explain why. "The hierarchy isn't clear because..." |
| **5. Be the Guide** | Don't just point out problems. Point toward solutions. |

### ✅ Constructive Phrases

- "You're onto something. What if we tweak just this one piece?"
- "Let's revisit this — right now, it's not solving for X."
- "What was the intention here? It might be reading differently than expected."
- "This works because [reason]. Can we apply that same thinking to [other element]?"
- "I see what you're going for. Here's what might help it land better..."
- "The idea is strong. The execution needs another pass on [specific thing]."

### ❌ Shutdown Phrases to Avoid

Never say:
- "I don't like it."
- "This feels off."
- "This doesn't work."
- "This isn't what I expected."
- "You're not getting it right."
- "Start over."
- "That's not Devalok."

These are vague, unhelpful, and can damage confidence. Always explain the why and offer direction.

---

## Publications & Initiatives

### Publications

| Name | Description |
|------|-------------|
| **Manas (मानस)** | Portfolio book — stories, process, thinking behind our work |
| **Sahayak (सहायक)** | Client Handbook — "one who helps" — given to every client |
| **Sankalan (संकलन)** | Monthly newsletter |

### Initiatives

| Name | Description |
|------|-------------|
| **Devalok Gurukul** | Design education initiative — making design education accessible |
| **Lokutsav (लोकउत्सव)** | Annual birth anniversary celebration (follows Panchang calendar) |
| **Aabhaar (आभार)** | Client gratitude events — "Tonight isn't about business, it's about the people in this room" |

---

## Contact Information

### Headquarters
**Address:** Lucknow, Uttar Pradesh, Bharat (India)

**Registered Office:** FF – 55, Khazana Market, Aashiana, near Bangla Bazaar, Lucknow – 226012, Uttar Pradesh

### US Operations
**Location:** Phoenix, Arizona, USA

### Digital Presence

| Purpose | URL |
|---------|-----|
| Main Website | devalok.in |
| Portfolio | devalok.in/works |
| Services | dvlk.in/services |
| Booking | talk.devalok.in |
| Short URLs | dvlk.in/[project] |
| Break Framework | tbf.devalok.in |
| Karm | karm.devalok.in |

### Email

| Purpose | Address |
|---------|---------|
| General | hello@devalok.in |
| Newsletter | sankalan@devalok.in |
| People & Culture | pac@devalok.in |

### Phone

| Location | Number |
|----------|--------|
| India | +91 77548 50181 |
| USA | +1 (602) 693 2521 |

---

*Reference: operations.md | Version 2.1.0*
