# Devalok Voice & Tone Guide

> **आत्मतः शिल्पं कृत्वा** — "From the soul, we craft."

This file defines how Devalok sounds in all communications.

---

## The Devalok Sound

| Attribute | How It Shows Up |
|-----------|-----------------|
| **Warm & Personal** | Never cold or transactional. We speak to people, not at them. Every message feels like it comes from a real person who cares. |
| **Story-driven** | Lead with meaning and narrative, not features or deliverables. Context before content. The "why" before the "what." |
| **Rooted in Tradition** | Indian aesthetic sensibility, Sanskrit/Hindi terms used naturally. We honor where we come from without being performative. |
| **Confident but Humble** | Expert without arrogance. We're mediums, not masters. We know our craft but never talk down to anyone. |
| **Detail-obsessed** | Thorough and comprehensive. Nothing left to chance. We think through implications and edge cases. |
| **Values-forward** | Purpose before process. Intent before execution. We lead with why things matter. |

---

## Tone Calibration by Context

| Context | Tone Adjustment |
|---------|-----------------|
| **New client inquiry** | Warm, curious, welcoming. Show genuine interest. |
| **Ongoing project** | Collaborative, clear, energized. Partnership feel. |
| **Difficult news** | Honest, empathetic, solution-oriented. Never defensive. |
| **Celebration** | Joyful, generous with credit, humble about our role. |
| **Internal team** | Direct, supportive, casual but respectful. |
| **Social media** | Thoughtful, insight-driven, never promotional. |
| **Proposals** | Visionary, confident, partnership-focused. |

---

## Greeting Protocol: Namaskar (नमस्कार)

**Namaskar** is the standard greeting across Devalok communications.

### ✅ When to Use Namaskar

- Opening formal communications
- Client emails (first contact and ongoing)
- External content and announcements
- Proposals and official documents
- Newsletter openings

### When It May Be Skipped

- Internal team messages
- Casual follow-ups where already used
- Quick replies in ongoing threads
- Matching casual energy set by recipient

### Format

- `Namaskar [Name],` — for direct address
- `Namaskar,` — for general audiences

---

## Hindi/Sanskrit Usage

### With Indian Clients or Internal Communications

Use terms naturally without explanation:

- Namaskar, Lokwasi, Sahayak, Karyakram, Manas, Sankalan
- Aabhaar, Lokutsav, Lokgranth, Karm
- आत्मतः शिल्पं कृत्वा

### With International/Non-Indian Clients

Use terms when they add meaning, and briefly explain on first use:

> "We call our client handbook *Sahayak* — meaning 'one who helps' — because that's exactly what it's designed to do."

> "This is *Aabhaar*, our evening of gratitude, where we celebrate the relationships that make our work meaningful."

> "Our philosophy, *आत्मतः शिल्पं कृत्वा*, translates to 'From the soul, we craft' — a reminder that we're mediums for bringing meaningful ideas to life."

**Rule:** Never force Hindi/Sanskrit for decoration. Use it when it carries meaning or creates connection.

---

## Signature Phrases

### Intentional Usage — Less is More

Signature phrases carry weight precisely because they're used sparingly. They are not decorations or fillers — they are reserved for moments that matter.

**Use signature phrases when:**
- Closing significant documents (major proposals, brand guidelines, annual communications)
- Brand-defining moments that warrant philosophical grounding
- Formal introductions to new clients or partners
- Content where the philosophy genuinely adds meaning

**Do NOT use signature phrases when:**
- Routine email updates or project check-ins
- Casual internal communications
- Every template footer by default
- Social media posts (unless truly warranted)
- Filling space or sounding "on-brand"

**Especially for आत्मतः शिल्पं कृत्वा:**
This is the core philosophy statement. It should appear only in contexts where its meaning resonates — not scattered across every communication. When overused, it loses its power. Reserve it for moments where the sentiment of "from the soul, we craft" genuinely applies.

### Available Phrases

Use these when contextually appropriate:

- "From the soul, we craft."
- "Different by Design"
- "Soulful craft"
- "Design that holds meaning"
- "A brand is a living presence"
- "Soul, intention, and execution intersect"
- "Everything starts with a CONVERSATION. A conversation leads to UNDERSTANDING. And understanding leads to CREATION."
- "For the Lokwasis, by the Lokwasis" *(internal only)*

---

## Philosophy Statements

Use these when explaining Devalok's approach:

> "The universe is always in motion — creating, sustaining, evolving. We see design as part of that rhythm: a cycle of refinement where ideas take shape, fall apart to make space for new ones, and return in their strongest form."

> "To craft is to engage with both the self and the world, to listen closely, to question deeply, and to push beyond what is known in pursuit of something meaningful. This is the spirit that shapes our practice at Devalok, where soul, intention, and execution intersect."

> "Design, for us, is never just about how something looks — it's about what it holds. A moment to go deeper, understand your vision better, and create something that truly resonates with you and your audience."

---

## Banned Language

### ❌ Corporate Jargon (Never Use)

| Banned | Alternative |
|--------|-------------|
| Synergy | Collaboration, working together |
| Leverage (as verb) | Use, build on |
| Optimize / Optimization | Refine, improve |
| Scalable / Scale | Grow, expand |
| Circle back | Follow up, reconnect |
| Bandwidth | Availability, capacity |
| Deliverables | What we'll share, the work |
| Touchpoint | Moment, interaction |
| Stakeholder | Team, or name them specifically |
| Loop in | Include, bring in |
| Take offline | Discuss separately |
| Move the needle | Make progress, have impact |
| Low-hanging fruit | Quick wins, immediate opportunities |
| Value-add | Benefit, contribution |
| Ideate | Explore ideas, brainstorm |
| Best-in-class | Excellent, outstanding |
| Cutting-edge | Innovative, modern |
| Disrupt / Disruptive | Transform, change |
| Pivot | Shift, change direction |
| Ecosystem | System, environment |
| Actionable insights | Clear recommendations |
| Boil the ocean | Be overly ambitious |
| Synergize | Work together |

### ❌ Banned Tones

Never sound like this:

- Salesy or pushy
- Pressure tactics or false urgency ("Limited time!" "Act now!")
- Cold, transactional, robotic
- Arrogant or condescending
- Generic agency-speak
- Overly formal or stiff
- Subservient or desperate
- Defensive

### ❌ Banned Openers

Never start communications with:

| Banned Opener | Why It's Banned |
|---------------|-----------------|
| "We at Devalok..." | Overused |
| "I hope this email finds you well" | Generic |
| "As per our conversation..." | Stiff |
| "I wanted to reach out..." | Weak |
| "Just following up..." | Passive |
| "Per my last email..." | Passive-aggressive |
| "To whom it may concern" | Impersonal |
| "Dear Sir/Madam" | Outdated |

### ✅ Better Alternatives

Instead of banned openers:

- "Namaskar [Name]," + specific reference to them or last interaction
- "It was wonderful speaking with you about [specific thing]..."
- "Thank you for sharing [specific thing] with us..."
- "After our conversation, I couldn't stop thinking about [specific idea]..."
- "[Name], I have some thoughts on [topic] I'd love to share..."

---

## Sign-off Phrases

Choose based on context and relationship:

### Formal / New Relationship
- "Looking forward to the next step together."
- "Excited to see where this goes."
- "With warmth, [Name]"

### Ongoing / Warm Relationship
- "Take your time with this — we're here when you're ready."
- "Can't wait to hear your thoughts."
- "More soon, [Name]"
- "Until we speak again, [Name]"

### Internal
- Use first names, casual closings
- Emojis sparingly if appropriate

---

## Writing Comparison Examples

### ❌ Not Devalok:
> "We leverage cutting-edge design methodologies to optimize brand performance and drive scalable growth solutions."

### ✅ Devalok:
> "We listen before we design. We question before we create. Every brand we touch carries intention — because design without meaning is just decoration."

---

### ❌ Not Devalok:
> "Our team will circle back with deliverables per the agreed timeline."

### ✅ Devalok:
> "We'll share the first directions by Thursday. Take your time with them — these ideas need space to breathe before we refine."

---

### ❌ Not Devalok:
> "Please find attached the proposal document for your review and consideration."

### ✅ Devalok:
> "I've put together our thoughts on how we could work together. Take your time with it — I think you'll see your vision reflected back clearly."

---

## Quality Checklist: All Communications

Before sending anything:

- [ ] Does it sound like Devalok, not a generic agency?
- [ ] Is the tone warm and human?
- [ ] Is it free of banned jargon and phrases?
- [ ] Are next steps clear (if applicable)?
- [ ] Would we be proud to send this?

---

*Reference: voice.md | Version 2.1.0*
